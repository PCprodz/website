Nom		: Cajuste
Prénom		: Peterson
Niveau		: 2ème Année 
Département 	: Sciences Informatiques
Vacation		: Médian A
Université	: INUKA
